var group__bridgeif__opts =
[
    [ "BRIDGEIF_DEBUG", "group__bridgeif__opts.html#gaab45e20e9b09a98217994082968cec73", null ],
    [ "BRIDGEIF_FDB_DEBUG", "group__bridgeif__opts.html#ga72e389f592470dc50288a68f3db70730", null ],
    [ "BRIDGEIF_FW_DEBUG", "group__bridgeif__opts.html#gac456e97b1b0e9a57449596a2b229763a", null ],
    [ "BRIDGEIF_MAX_PORTS", "group__bridgeif__opts.html#ga6fe03b84359150b7dea3dfca942b6414", null ],
    [ "BRIDGEIF_PORT_NETIFS_OUTPUT_DIRECT", "group__bridgeif__opts.html#ga5aed5cd9b01ba1345b47845cd04ca30d", null ]
];