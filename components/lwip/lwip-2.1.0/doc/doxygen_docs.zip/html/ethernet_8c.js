var ethernet_8c =
[
    [ "ethernet_input", "group__lwip__nosys.html#ga6a10c58b82c56d02c48b3cfa2c2494ff", null ],
    [ "ethernet_output", "group__ethernet.html#gac9cad5802bfa3d885f13d2ba0f40b778", null ]
];