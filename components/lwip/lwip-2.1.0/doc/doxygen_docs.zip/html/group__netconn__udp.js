var group__netconn__udp =
[
    [ "netconn_disconnect", "group__netconn__udp.html#ga90bb4c4d1af6602a655b78fce0520402", null ],
    [ "netconn_join_leave_group", "group__netconn__udp.html#gaaaf2f92eeb38dca70b3e6ad98c3c45ed", null ],
    [ "netconn_join_leave_group_netif", "group__netconn__udp.html#ga5db2a1cf06a5fbb36f433e637da8729b", null ],
    [ "netconn_send", "group__netconn__udp.html#gac4d4d10153d47c80a783c34b27c66238", null ],
    [ "netconn_sendto", "group__netconn__udp.html#ga8e1d852119bda1e1b602c2995282ef0c", null ]
];