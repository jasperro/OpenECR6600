var group__httpd =
[
    [ "Options", "group__httpd__opts.html", "group__httpd__opts" ],
    [ "tCGI", "structt_c_g_i.html", null ],
    [ "tCGIHandler", "group__httpd.html#gafe011a487c5e8d03a6b2f629e14e6b5c", null ],
    [ "tSSIHandler", "group__httpd.html#gaf88dacc4f18d299084cab75252001319", null ],
    [ "http_set_cgi_handlers", "group__httpd.html#gae1ec09532ff7fc622e1860727bf2c897", null ],
    [ "http_set_ssi_handler", "group__httpd.html#ga8834ecb16d9a7d6c128bdf9514b7879c", null ],
    [ "httpd_init", "group__httpd.html#gac364305cee969a0be43c071722b136e6", null ],
    [ "httpd_inits", "group__httpd.html#gafaedb1911a83854b1e9835132db64409", null ],
    [ "httpd_post_begin", "group__httpd.html#ga6cb33693ee8f0c054be82a968ceff582", null ],
    [ "httpd_post_data_recved", "group__httpd.html#gaca4357acf5c988b28123bc6f23540380", null ],
    [ "httpd_post_finished", "group__httpd.html#ga477473f7ead250fec71f1f8b9926fec5", null ],
    [ "httpd_post_receive_data", "group__httpd.html#ga461409c8813c2a82ba63fde987c0e537", null ]
];